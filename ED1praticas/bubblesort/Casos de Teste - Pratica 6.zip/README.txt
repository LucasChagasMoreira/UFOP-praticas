Arquivo zip gerado em: 09/02/2023 15:57:39 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Prática 6