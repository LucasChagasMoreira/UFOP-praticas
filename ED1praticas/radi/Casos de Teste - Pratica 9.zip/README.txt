Arquivo zip gerado em: 09/03/2023 16:37:03 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Prática 9